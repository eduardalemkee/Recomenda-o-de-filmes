//O Rei Leão, Livre, Aventura, Fantasia
//A Pequena Sereia, Livre, Aventura, Fantasia
//Harry Potter, 10, Drama, Aventura, Fantasia
//A Menina que Roubava Livros, 14, Drama
//Com Amor, Simon, 12, Drama
//Como Treinar Seu Dragão, 12, Fantasia, Aventura
//O Poderoso Chefão, 10, Drama
let campoIdade;
let campoFantasia;
let campoAventura;
let campoClassificacao;

function setup() {
  createCanvas(400, 400);
  campoIdade = createInput("15");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
  
  // Criar o seletor de classificação indicativa
  campoClassificacao = createSelect();
  campoClassificacao.option('14 anos');
  campoClassificacao.option('16 anos');
  campoClassificacao.option('18 anos');
  campoClassificacao.selected('14 anos');
}

function draw() {
  background(255, 255, 110);
  
  let idade = int(campoIdade.value()); // Converte a idade para número
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let classificacao = campoClassificacao.value();
  
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura, classificacao);
  text(recomendacao, 10, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura, classificacao) {
  // Lógica para classificar e filtrar as recomendações de acordo com a faixa etária
  if (classificacao === '14 anos') {
    if (idade <= 10 && gostaDeFantasia && gostaDeAventura) {
      return "Recomendamos 'Harry Potter' - Uma aventura mágica!";
    } else if (idade <= 10 && !gostaDeFantasia && !gostaDeAventura) {
      return "Que tal 'O Poderoso Chefão'? Um clássico imperdível.";
    } else if (idade <= 10 && !gostaDeFantasia && gostaDeAventura) {
      return "Você pode gostar de 'O Rei Leão' - Uma aventura emocionante.";
    } else if (idade > 10 && gostaDeFantasia && gostaDeAventura) {
      return "Recomendamos 'Harry Potter' - Uma aventura mágica!";
    } else if (idade > 10 && !gostaDeFantasia && gostaDeAventura) {
      return "Você pode gostar de 'Percy Jackson' - Uma aventura mitológica!";
    } else {
      return "Sugira algo mais para encontrarmos o filme ideal!";
    }
  }
  
  if (classificacao === '16 anos') {
    if (idade <= 10 && gostaDeFantasia && gostaDeAventura) {
      return "Que tal 'O Rei Leão'? Uma linda jornada de aventura.";
    } else if (idade <= 10 && !gostaDeFantasia && !gostaDeAventura) {
      return "Recomendamos 'O Poderoso Chefão' - Um clássico de ação e drama.";
    } else if (idade <= 10 && !gostaDeFantasia && gostaDeAventura) {
      return "Você pode gostar de 'Jumanji' - Uma diversão com muitas aventuras.";
    } else if (idade > 10 && gostaDeFantasia && gostaDeAventura) {
      return "Recomendamos 'O Senhor dos Anéis' - Uma grande aventura épica!";
    } else if (idade > 10 && !gostaDeFantasia && gostaDeAventura) {
      return "Indiana Jones é uma ótima opção para quem adora ação!";
    } else {
      return "Sugira algo mais para encontrarmos o filme ideal!";
    }
  }
  
  if (classificacao === '18 anos') {
    if (idade > 10 && gostaDeFantasia && gostaDeAventura) {
      return "Recomendamos 'O Senhor dos Anéis' - Uma jornada épica e complexa!";
    } else if (idade > 10 && !gostaDeFantasia && gostaDeAventura) {
      return "Que tal 'Mad Max: Estrada da Fúria'? Uma aventura intensa!";
    } else if (idade > 10 && gostaDeFantasia && !gostaDeAventura) {
      return "Você pode gostar de 'O Labirinto do Fauno' - Uma fantasia sombria e poética.";
    } else if (idade > 10 && !gostaDeFantasia && !gostaDeAventura) {
      return "Você pode gostar de 'O Poderoso Chefão' - Um clássico de drama e crime.";
    } else {
      return "Sugira algo mais para ajustarmos a recomendação!";
    }
  }

  return "Escolha uma classificação para a recomendação!";
}